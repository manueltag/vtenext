<?php
$mod_strings = array(
	'Targets'=>'Ziele',
	'SINGLE_Targets'=>'Ziel',
	'Target Name'=>'Ziel Name',
	'Target No'=>'Ziel-Nr.',
	'Target Type'=>'Ziel Typ',
	'Target State'=>'Ziel Status',
	'End Time'=>'Terminvorgabe',
	'Assigned To'=>'Zugewiesen an',
	'Description'=>'Beschreibung',
	'Modified Time'=>'geänderte Zeit',
	'LBL_LOAD_LIST'=>'lade Liste',
	'Select One'=>'Wähle einen',
	'-- Nessuno --'=>'-- Keiner --',
	'LBL_LOAD_REPORT'=>'Lade Bericht',
	'LBL_TARGETS_INFORMATION'=>'Zielinformationen',
	'LBL_CUSTOM_INFORMATION'=>'Spezielle Informationen',
	'LBL_DESCRIPTION_INFORMATION'=>'Beschreibungsinformationen:',
	'Created Time'=>'Erstellt am',
);
?>