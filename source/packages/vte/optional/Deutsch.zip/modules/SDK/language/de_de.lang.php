<?php
$mod_strings = array(
	'LBL_WATERMARK'=>'Zur Suche Wert einfügen',
	'LBL_NO_RECORDS'=>'Keine Elemente gefunden',
);
?>