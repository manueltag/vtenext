<?php
$mod_strings = array(
	'LBL_BOOKMARKED_URL'=>'URL\'s mit Lesezeichen',
	'LBL_MANAGE_BOOKMARKS'=>'Bearbeite Lesezeichen',
	'LBL_BOOKMARK_LIST'=>'Lesezeichenliste',
	'LBL_NEW_BOOKMARK'=>'Neues Lesezeichen',
	'LBL_BOOKMARK'=>'Lesezeichen',
	'LBL_NAME'=>'Name :',
	'LBL_URL'=>'URL :',
	'LBL_ADD'=>'Erstelle',
	'LBL_SNO'=>'#',
	'LBL_BOOKMARK_NAME_URL'=>'Lesezeichenname & URL',
	'LBL_TOOLS'=>'Werkzeuge',
	'LBL_MANAGE_SITES'=>'Seiteneinstellungen bearbeiten',
	'LBL_MY_SITES'=>'alle Seiten',
	'LBL_SET_DEFAULT_BUTTON'=>'als Standard setzen',
	'LBL_MY_BOOKMARKS'=>'Meine Lesezeichen',
);
?>