<?php
$mod_strings = array(
	'YearlyBudget'=>'jährliches  Budget',
	'LBL_DESCRIPTION_INFORMATION'=>'Beschreibungsinformationen',
	'LBL_PRODUCTLINES_INFORMATION'=>'Sortimentsinformationen',
	'ProductLines'=>'Sortimente',
	'SINGLE_ProductLines'=>'Sortimente',
	'LBL_CUSTOM_INFORMATION'=>'Individuelle Informationen',
	'ProductLineName'=>'Linienname',
);
?>