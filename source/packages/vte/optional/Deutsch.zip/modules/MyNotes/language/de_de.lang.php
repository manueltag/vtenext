<?php
$mod_strings = array(
	'MyNotes'=>'Notizen',
	'SINGLE_MyNotes'=>'Notiz',
	'LBL_MYNOTES_INFORMATION'=>'Notizinformationen',
	'Subject'=>'Titel',
	'Description'=>'Notiz',
	'Assigned To'=>'Zugeordnet zu',
	'Created Time'=>'Erstellt am',
	'Modified Time'=>'Zuletzt geändert am',
);
?>