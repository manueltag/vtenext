<?php
$mod_strings = array(
	'LBL_PRICEBOOK_INFORMATION'=>'Preislisteninformationen:',
	'LBL_CUSTOM_INFORMATION'=>'Zusätzliche Informationen',
	'LBL_DESCRIPTION_INFORMATION'=>'Beschreibung:',
	'Price Book Name'=>'Preislistenname',
	'Product Name'=>'Produktname',
	'Active'=>'Aktiv',
	'Description'=>'Beschreibung',
	'Created Time'=>'Erstellt am',
	'Modified Time'=>'geändert',
	'LBL_LIST_PRODUCT_NAME'=>'Produktname',
	'LBL_PRODUCT_CODE'=>'Produktcode',
	'LBL_PRODUCT_UNIT_PRICE'=>'Einheitenpreis',
	'LBL_PB_LIST_PRICE'=>'Listenpreis',
	'LBL_ACTION'=>'Aktion',
	'PriceBook'=>'Preisliste',
	'Currency'=>'Währung',
	'PriceBook No'=>'Preislistennummer',
);
?>