<?php
$mod_strings = array(
	'Mobile'=>'Mobil',
);
?>