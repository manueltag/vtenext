<?php
$mod_strings = array(
	'LBL_NEW_FORM_TITLE'=>'Neuer Benutzer',
	'LBL_MODULE_NAME'=>'Administration',
	'LBL_MODULE_TITLE'=>'Administration: Home',
	'ERR_DELETE_RECORD'=>'Bitte definieren eine Aufzeichnungsnummer um die Organisation zu löschen.',
);
?>