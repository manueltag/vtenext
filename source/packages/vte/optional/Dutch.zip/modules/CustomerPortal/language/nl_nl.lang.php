<?php
$mod_strings = array(
	'LBL_ADVANCED_SETTINGS'=>'Uitgebreide instellingen',
	'LBL_BASIC_SETTINGS'=>'Standaard instellingen',
	'CustomerPortal'=>'Klantportaal',
	'LBL_DISABLE'=>'Deactiveer',
	'LBL_ENABLE'=>'Activeer',
	'LBL_MODULE'=>'Module',
	'Module'=>'Module',
	'NO'=>'nee',
	'SELECT_TEMPLATE'=>'Selecteer het sjabloon',
	'SELECT_USERS'=>'Selecteer de gebruikers',
	'Sequence'=>'Volgorde',
	'LBL_TEMPLATE_DESCRIPTION'=>'Het hierboven geselecteerde sjabloon wordt gebruikt om de bevestingings e-mail te versturen voor toegang tot het portaal',
	'LBL_USER_DESCRIPTION'=>'Het hierboven geselecteerde gebruikersprofiel wordt gebruikt om de juistheid van de velden in het klantportaal te controleren.',
	'LBL_VIEW_ALL_RECORD'=>'Alle gekoppelde records weergeven?',
	'Visible'=>'Zichtbaar',
	'YES'=>'ja',
);
?>