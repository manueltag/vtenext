<?php
$mod_strings = array(
	'LBL_WATERMARK'=>'Geef een waarde in om te zoeken',
	'LBL_NO_RECORDS'=>'Geen elementen gevonden',
);
?>