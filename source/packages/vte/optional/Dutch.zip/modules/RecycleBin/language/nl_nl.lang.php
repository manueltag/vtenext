<?php
$mod_strings = array(
	'MSG_EMPTY_RB_CONFIRMATION'=>'Weet u zeker dat u alle verwijderde records definitief uit de database wilt wissen?',
	'LBL_EMPTY_RECYCLEBIN'=>'Maak prullenmand leeg',
	'LBL_NO_PERMITTED_MODULES'=>'',
	'LBL_EMPTY_MODULE'=>'Geen records gevonden in de module om te herstellen.',
	'RecycleBin'=>'Prullenbak',
	'LBL_MASS_RESTORE'=>'Herstellen',
	'LNK_RESTORE'=>'Herstellen',
	'LBL_SELECT_MODULE'=>'Selecteer Module',
);
?>