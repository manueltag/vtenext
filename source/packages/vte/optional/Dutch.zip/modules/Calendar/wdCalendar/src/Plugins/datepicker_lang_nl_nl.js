var i18n = jQuery.extend({}, i18n || {}, {
    datepicker: {
        dateformat: {
            "fulldayvalue": "M/d/yyyy",
            "separator": "/",
            "year_index": 2,
            "month_index": 0,
            "day_index": 1,
            'sun':'Zo',
			'mon':'Ma',
			'tue':'Di',
			'wed':'Wo',
			'thu':'Do',
			'fri':'Vrij',
			'sat':'Za',
			'jan':'jan',
			'feb':'feb',
			'mar':'mrt',
			'apr':'apr',
			'may':'mei',
			'jun':'jun',
			'jul':'jul',
			'aug':'aug',
			'sep':'sep',
			'oct':'okt',
			'nov':'nov',
			'dec':'dec',
            "postfix": ""
        },
        ok: 'Ok',
		cancel: 'Annuleren',
		today: 'Vandaag',
		prev_month_title: 'Vorige maand',
		next_month_title: 'Volgende maand'
    }
});