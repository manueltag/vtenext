<?php
$mod_strings = array(
	'LBL_SNO'=>'#',
	'LBL_ADD'=>'Toevoegen',
	'LBL_BOOKMARK'=>'Bookmark/bladwijzer',
	'LBL_BOOKMARK_LIST'=>'Bookmark/bladwijzerlijst',
	'LBL_BOOKMARK_NAME_URL'=>'Bookmark/bladwijzer & URL',
	'LBL_BOOKMARKED_URL'=>'Bookmark/bladwijzer',
	'LBL_MANAGE_BOOKMARKS'=>'Beheer bookmarks',
	'LBL_MANAGE_SITES'=>'Beheer sites',
	'LBL_MY_BOOKMARKS'=>'mijn Bookmarks',
	'LBL_NAME'=>'Naam',
	'LBL_NEW_BOOKMARK'=>'Nieuwe bookmark',
	'LBL_SET_DEFAULT_BUTTON'=>'Gebruik als standaardwaarde',
	'LBL_MY_SITES'=>'Sites',
	'LBL_TOOLS'=>'Tool',
	'LBL_URL'=>'URL',
);
?>