<?php
$mod_strings = array(
	'Mobile'=>'Mobiel',
);
?>