<?php
$mod_strings = array(
	'LBL_NEW_PRICEBOOKS' => 'Aanmaken prijslijst',
	'LBL_ACTION'=>'Actie',
	'Active'=>'Actief',
	'Created Time'=>'Aangemaakt om',
	'Currency'=>'Valuta',
	'LBL_CUSTOM_INFORMATION'=>'Notities',
	'Description'=>'Omschrijving',
	'LBL_DESCRIPTION_INFORMATION'=>'Naam omschrijving',
	'LBL_PB_LIST_PRICE'=>'Catalogusprijs',
	'Modified Time'=>'Tijdstip gewijzigd',
	'LBL_PRODUCT_CODE'=>'Artikelnummer',
	'PriceBook'=>'prijslijst',
	'LBL_PRICEBOOK_INFORMATION'=>'prijslijst Informatie:',
	'Price Book Name'=>'prijslijst naam',
	'PriceBook No'=>'prijslijst nr.',
	'Product Name'=>'Productnaam',
	'LBL_LIST_PRODUCT_NAME'=>'Productnaam',
	'LBL_PRODUCT_UNIT_PRICE'=>'Stuksprijs',
);
?>