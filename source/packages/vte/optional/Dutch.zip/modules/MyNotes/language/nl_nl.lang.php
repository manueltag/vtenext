<?php
$mod_strings = array(
	'MyNotes'=>'Opmerkingen',
	'SINGLE_MyNotes'=>'Opmerkingen',
	'LBL_MYNOTES_INFORMATION'=>'Informatie',
	'Subject'=>'Naam',
	'Description'=>'Opmerking',
	'Assigned To'=>'Toegewezen aan',
	'Created Time'=>'Aangemaakt om:',
	'Modified Time'=>'Aangepast om:',
);
?>