<?php
$mod_strings = array(
	'LBL_NEW_TARGETS' => 'Aanmaken Doelstelling',
	'Assigned To'=>'Toegewezen aan',
	'Created Time'=>'gemaakt Tijd',
	'LBL_CUSTOM_INFORMATION'=>'aangepaste informatie',
	'Description'=>'Omschrijving',
	'LBL_DESCRIPTION_INFORMATION'=>'Beschrijving Informatie',
	'End Time'=>'Eindtijd',
	'LBL_LOAD_LIST'=>'Laad lijst',
	'LBL_LOAD_REPORT'=>'Laad rapport',
	'Modified Time'=>'Tijdstip gewijzigd',
	'Select One'=>'Selecteer een',
	'SINGLE_Targets'=>'Doelstelling',
	'LBL_TARGETS_INFORMATION'=>'Doelstelling informatie',
	'Target Name'=>'Naam doelstelling',
	'Target No'=>'Nummer doelstelling',
	'Target State'=>'Staat (doel)',
	'Target Type'=>'Type doel',
	'Targets'=>'Doelstellingen',
);
?>