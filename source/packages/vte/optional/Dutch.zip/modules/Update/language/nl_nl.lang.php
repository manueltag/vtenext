<?php
$mod_strings = array(
	'LBL_SIGN_IN_CHANGE'=>'Wijzig login',
	'LBL_CURRENT_VERSION'=>'Huidige bouw',
	'LBL_MAX_VERSION'=>'Laatste versie beschikbaar',
	'LBL_SIGN_IN_DETAILS'=>'Login details',
	'LBL_PASWRD'=>'wachtwoord /wachtwoord',
	'LBL_SPECIFICIED_VERSION'=>'Gespecificeerde versie',
	'LBL_SPECIFIC_VERSION'=>'Bepaal de versie',
	'LBL_URL'=>'SVN adres',
	'LBL_UPDATE_PACK_INVALID'=>'Deze update is niet mogelijk met uw versie van VTE. Neem contact op met CRMVillage.BIZ of uw Business Partner voor de juiste versie.',
	'LBL_UPDATE'=>'Update',
	'LBL_UPDATE_BUTTON'=>'Update',
	'LBL_UPDATE_DETAILS'=>'Update gegevens',
	'LBL_UPDATE_TO'=>'Update naar',
	'LBL_UPDATE_DESC'=>'Update versie',
	'LBL_USERNAME'=>'Gebruiker',
);
?>