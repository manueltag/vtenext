<?php
$mod_strings = array(
	'RecycleBin'=>'Recycle Bin',
	'MSG_EMPTY_RB_CONFIRMATION'=>'Are you sure, you want to Permanently remove all the deleted records from your database?',
	'LBL_SELECT_MODULE'=>'Select Module',
	'LBL_EMPTY_MODULE'=>'No records found to Restore in module',
	'LBL_MASS_RESTORE'=>'Restore',
	'LBL_EMPTY_RECYCLEBIN'=>'Empty Recycle Bin',
	'LNK_RESTORE'=>'restore',
	'LBL_NO_PERMITTED_MODULES'=>'No authorised modules available',
);
?>