<?php
$mod_strings = array(
	'CustomerPortal'=>'CustomerPortal',
	'LBL_BASIC_SETTINGS'=>'Basic Settings',
	'LBL_ADVANCED_SETTINGS'=>'Advanced Settings',
	'LBL_MODULE'=>'Module',
	'LBL_VIEW_ALL_RECORD'=>'View All Related Records ?',
	'YES'=>'Yes',
	'NO'=>'No',
	'LBL_USER_DESCRIPTION'=>'The above selected User profile will manage the fields shown in the Customer Portal',
	'SELECT_USERS'=>'Select the Users',
	'LBL_DISABLE'=>'Disable',
	'LBL_ENABLE'=>'Enable',
	'Module'=>'Module',
	'Sequence'=>'Sequence',
	'Visible'=>'Visible',
	'SELECT_TEMPLATE'=>'Select the Template',
	'LBL_TEMPLATE_DESCRIPTION'=>'The above selected template will be used to send the mail of subscription to the portal.',
);
?>