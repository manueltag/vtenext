<?php
$mod_strings = array (
  'LBL_MODULE_NAME' => 'RSS',
  'LBL_MODULE_TITLE' => 'RSS: Principal',
  'LBL_NEW_RSS_ENTRY' => 'URL Novo alimentador Notícias RSS:',
  'LBL_SEARCH_RSS' => 'Pesquisar Títolo:',
  'LBL_NEW_RSS_BUTTON' => 'Adicionar',
  'LBL_STARRED_RSS' => 'RSS Principais',
  'LBL_POP_CRM_RSS' => 'Principais Alimentadores relacionados com CRM',
  'LBL_ALL_RSS_FEEDS' => 'Todos os Alimentadores RSS:',
  'LBL_VTIGER_RSS_READER' => 'Leitor RSS',
  'LBL_MORE' => 'Mais....',
  'LBL_SUBJECT' => 'Assunto',
  'LBL_SENDER' => 'Remetente',
  'LBL_CATEGORY' => 'Categoria:',
  'LBL_FEED' => 'Alimentador :',
  'LBL_FEED_SOURCES' => 'Fontes Alimentador',
  'LBL_ADD_RSS_FEED' => 'Adicionar Alimentador RSS:',
  'LBL_DELETE_BUTTON' => 'Apagar',
  'LBL_SET_DEFAULT_BUTTON' => 'Definir como Padrão',
  'LBL_FEEDS_LIST' => 'Lista de Alimentadores de:',
  'LBL_ERROR_MSG' => 'Não há RSS Feeds são selecionados ou suas configurações de proxy não estão corretos',
  'LBL_REGRET_MSG' => 'Desculpe: Não é possível acessar a URL do RSS',
  'UNABLE_TO_SAVE' => 'Impossível salvar URL do alimentador RSS',
  'NOT_A_VALID' => 'Inválido RSS Feed ou suas configurações de proxy não é correto',
		'INVALID_RSS_URL'=>'URL RSS inválido',

);
?>