<?php
$mod_strings = array (
  'LBL_BOOKMARKED_URL' => 'URLs Favoritos',
  'LBL_MANAGE_BOOKMARKS' => 'Administrar Favoritos',
  'LBL_BOOKMARK_LIST' => 'Lista Favoritos',
  'LBL_MY_BOOKMARKS' => 'Meus Favoritos',
  'LBL_NEW_BOOKMARK' => 'Novo Favorito',	//crmv@21616
  'LBL_BOOKMARK' => 'Favorito',
  'LBL_NAME' => 'Nome',
  'LBL_URL' => 'URL :',
  'LBL_ADD' => 'Adicionar',
  'LBL_SNO' => '#',
  'LBL_BOOKMARK_NAME_URL' => 'Nome Favoritos & URL',
  'LBL_TOOLS' => 'Ferramentas',
  'LBL_MANAGE_SITES' => 'Administra��o Sites',
  'LBL_MY_SITES' => 'Links de Sites',
  'LBL_SET_DEFAULT_BUTTON' => 'Definir como Padr�o',

);
?>
