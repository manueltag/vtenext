<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * Contribution: Different Solutions GmbH, Waldkraiburg. www.vtiger.de
 ********************************************************************************/


$mod_strings = array(
'Projects'=>'Projetos',
//crmv@14468
'SINGLE_Projects' => 'Projeto',
//crmv@14468 end
'LBL_INFORMATION' => 'Informa��o Projeto',
'LBL_PROJECT_INFORMATION'=>'Informa��o Projeto',
'LBL_CUSTOM_INFORMATION'=>'Informa��o Personalizada',
'LBL_DESCRIPTION_INFORMATION'=>'Informa��o Descri��o',

//Mapping for price book
'Price Book Name'=>'Nome Lista de Pre�os',
'Product Name'=>'Nome Produto',
'Active'=>'Ativo',
'Description'=>'Descri��o',
'Created Time'=>'Data e Hora de Cria��o',
'Modified Time'=>'Data e Hora de Modifica��o',
'LBL_LIST_PRODUCT_NAME'=>'Nome Produto',
'LBL_PRODUCT_CODE'=>'C�digo Produto',
'LBL_PRODUCT_UNIT_PRICE'=>'Pre�o Unidade',
'LBL_PB_LIST_PRICE'=>'Pre�o Lista de Pre�os',
'LBL_ACTION'=>'A��o',
'PriceBook'=>'Lista de Pre�os',

'failtype'=>'Outras atividades',
'End Project'=>'Projeto conclu�do?',
'Internal Project Nummer'=>'Nome projeto',
'External Project Nummer'=>'Referente Comercial',
'Account Name'=>'Conta',
'Projectleader Customer'=>'Contato Conta para o Projeto',
'Total Hour'=>'Horas Totais',
'Category'=>'Categoria',
'Project Start'=>'In�cio Projeto',
'Project End'=>'T�rmino Projeto',
'Total External'=>'Custo Hor�rio externo',
'Total Internal'=>'Custo Hor�rio interno',
'Projectleader OSS'=>'L�der do Projeto',
'Subtotal'=>'Subtotal',
'Total_Hours'=>'Total Horas',

'LBL_ADD_WORKERS'=>'Recursos atribu�dos',
'LBL_FREE_HOURS'=>'Horas Atribu�das',          
'LBL_ERROR_MAX_TOTAL_HOURS'=>'Por favor controlar o n�mero de horas!',
'LBL_ERROR_MAX_HOUR_FOR_USER'=>'Por favor controlar o n�mero de horas!',                      
'LBL_ERROR_PROJECTNAME_EXIST'=>' Este referente interno do projeto � j� existente',
'LBL_ERROR_TOTAL_HOUR_PART1'=>'O n�mero de horas deve ser maior que ',
'LBL_ERROR_TOTAL_HOUR_PART2'=>'Hora',

'LBL_ERROR_MAX_HOUR_PART'=>'� poss�vel hospitar no m�ximo 24 horas.',
'LBL_ERROR_MAX_HOUR_FOR_PROJECT'=>' Voc� inseriu muitas horas para este projeto!',
'LBL_ERROR_WORKER_SELECT_HOURS'=>'Um recurso efetuou muitas horas!',
'LBL_ERROR_CLEAR_USSER'=>'O recurso j� efetuou horas neste projeto. N�o � poss�vel apag�-las. !',
'ERROR_ENTER_HOUR_IS_SMALL'=>'Um recurso efetuou muitas horas !',
'ERROR_ENTER_HOUR_IS_SMALL_PARTA'=>'O recurso',
'ERROR_ENTER_HOUR_IS_SMALL_PARTB'=>'Efetuou muitas horas!',
'LBL_ERROR_ENTRIE_MINUS_VALUE'=>'Voc� pode inserir somente valores maiores de 0 !',
'LBL_ERROR_ENTRIE_WORKER_MINUS_VALUE_PARTA'=>' As horas n�o foram inseridas',
'LBL_ERROR_ENTRIE_WORKER_MINUS_VALUE_PARTB'=>'para este recurso.',
'ERROR_NO_ENTER_SUM'=>'Vc� pode inserir somente n�meros inteiros',
'LBL_TOTAL_FREE_HOUR'=>'Total horas n�o atribu�das',
'LBL_TOTAL_ENTER_HOUR'=>'Total horas n�o efetuadas sobre horas atribu�das',
'LBL_TOTAL_FREE_HOUR_RESOURCE'=>'Total horas atribu�das',
'LBL_TOTAL_ENTER_HOUR_RESOURCE'=>'Total horas n�o efetuadas',
'LBL_TOTAL_ASSIGNED_HOUR'=>'Total horas atribu�das',
'total_enter_hour'=>' horas n�o efetuadas',
'total enter hour'=>'horas n�o efetuadas',
'LBL_AMOUNT_HOUR'=>'N�mero de horas',
'LBL_WORKER_NAME'=>'Nome recurso',
'LBL_WORKER'=>'Recurso',

'LBL_INFORMATION'=>'Informa��o Projeto',
'LBL_BASIC_INFORMATION'=>'Administrar tempos de todos os Projetos ',
'LBL_PROJECT_INFORMATION'=>'Administrar tempos deste Projeto',

'LBL_PROJECT_LISTVIEW'=>'S�mario Projeto',


'LBL_PROJECTS_NAME'=>'Projetos',
'LBL_PROJECT_LISTVIEW'=>'Projetos',
'LBL_HOUR_TOTAL'=>'Horas Globais',    
'LBL_HOUR_FREE'=>'Horas abertas',

'LBL_HOUR_LOG'=>'Horas Empregadas',
'LBL_HOUR_OTHER_ACTIVITIES'=>'Outras atividades',
'LBL_HOUR_TOTAL'=>'Todas as atividades',
'LBL_HOUR_TOTAL_PROJECT'=>'Total horas dedicadas ao projeto',
'LBL_HOUR_TOTAL_VALUE'=>'Valor',

'LBL_OK_DATE'=>'OK',

'Travel'=>'Transferimento',
'Course'=>'Curso',
'Internal'=>'Interno',

'LBL_MONTH'=>'M�s',

'LBL_MONTH_01'=>'Janeiro',
'LBL_MONTH_02'=>'Fevereiro',
'LBL_MONTH_03'=>'Mar�o',
'LBL_MONTH_04'=>'Abril',
'LBL_MONTH_05'=>'Maio',
'LBL_MONTH_06'=>'Junho',
'LBL_MONTH_07'=>'Julho',
'LBL_MONTH_08'=>'Agosto',
'LBL_MONTH_09'=>'Setembro',
'LBL_MONTH_10'=>'Outubro',
'LBL_MONTH_11'=>'Novembro',
'LBL_MONTH_12'=>'Dezembro',

'Working'=>'Em andamento',
'Finished'=>'Conclu�do',
'Invoice'=>'Fatur�vel',

'LBL_DEDICADET_HOUR'=>'Horas dedicadas',
'LBL_INSCRIBED_HOUR'=>'Horas efetuadas',
'LBL_FREE_HOUR_B'=>'Horas abertas',

'LBL_ADD_TICKET'=>'Adicionar Ticket',
'LBL_ADDED_TICKETS'=>'Ticket Atribu�dos',
'ticket_id'=>'N�mero Ticket',
'status'=>'Status',
'description'=>'T�tulo',

'LBL_HRS'=>'Horas',
'LBL_NOTE'=>'Documento',
'Project Name'=>'Nome Projeto',
'LBL_PROJECT_EXIST' => 'Nome Projeto j� existente!',
'Project Status' => 'Status Projeto',
'State History' => 'Hist�rico Est�gios',

'LBL_INFORMATION'=>'Informa��o Projeto',
'LBL_BASIC_INFORMATION'=>'Administrar tempos de todos os Projetos ',
'LBL_PROJECT_INFORMATION'=>'Administar tempos deste Projeto',

//menu
'LBL_INFO_TITLE'=>'Informa��o Projeto',
'LBL_PROJECT_NAME_INTERNAL'=>'Nome Projeto Interno',
'LBL_PROJECT_NAME_EXTERNAL'=>'Nome Projeto Externo',
'LBL_INFO_HOUR'=>'Total horas dedicadas ao projeto',
'LBL_INFO_ASSIGN_TITLE'=>'Situa��o atribui��o horas',
'LBL_ASSIGN_ASSIGNED_HOUR'=>'Horas atribu�das',
'LBL_ASSIGN_NOTASSIGNED_HOUR'=>'Horas n�o atribu�das',
'LBL_DONE_TITLE'=>'Situa��o andamento horas',
'LBL_DONE_DONEHOUR'=>'Horas efetuadas',
'LBL_DONE_NOTDONEHOUR'=>'Horas n�o efetuadas',
'LBL_RESOURCE_TITLE'=>'Situa��o recursos',
'LBL_RESOURCE_ASSIGNED_HOUR'=>'Horas atribu�das',
'LBL_RESOURCE_NOTDONEHOUR'=>'Horas n�o efetuadas',
'LBL_HOURS_TODO'=>'Horas da efetuar',
'LBL_HOURS_DONE'=>'Horas efetuadas',
'LBL_ACTIVITY_TYPE'=>'Tipo de atividade',
'Open'=>'Aberto',
'In Progress' => 'Em andamento',				
'Closed' => 'Fechado',
);
?>