<?php

$mod_strings = Array (
'Mobile' => 'Mobile',

);

?>
