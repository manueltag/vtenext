<?php
$mod_strings = Array(
	'LBL_NEW_PROJECTMILESTONE' => 'Criar Marco Projeto',
	'LBL_MODULE_NAME'=>'Marco Projeto',
  	'LBL_MODULE_TITLE'=>'Marcos Projeto',
	'LBL_NEW_OPERATION'=>'Novo Marco Projeto',
	//crmv@521translation start
	'LBL_MILESTONES' => 'Marco Projeto',
	'LBL_MILESTONE' => 'Marco Projeto',
	'Project Milestone ID'=>'endereço Etapa', 
    'projectmilestones' => 'Marcos Projeto',
	//crmv@521translation end
    //added this to translate the module name in the main app menu
	'ProjectMilestone' => 'Marcos Projeto',
	'SINGLE_ProjectMilestone' => 'Marco Projeto',
	'LBL_CUSTOM_INFORMATION' => 'Informação Personalizada',
    'LBL_PROJECT_MILESTONE_INFORMATION' => 'Informação Marco Projeto',
    'LBL_DESCRIPTION_INFORMATION' => 'Informação Descrição',
    'Assigned To' => 'Atribuída a',
	'Milestone Date' => 'id Etapa',
	'Milestone' => 'Marco Projeto',
    //crmv@521translation start
	'Assigned To' => 'Atribuída à',
    'Milestone Date' => 'Data Marco',
    'Milestone' => 'Marco',
    'Type'=>'Tipo',
    //'linktoproject'=>'Link To',
    'Related Project' => 'Projeto Relacionado',
	 //crmv@521translation end
    'Related To' => 'Relacionado à',
    'projectid' => 'Relacionado à',
  	'administrative' => 'administrativo',
    'operative' => 'operativo',
    'other' => 'outro',
    'Created Time' => 'tempo criado',
    'Modified Time' => 'Data e Hora de Modificação',
    'description' => 'Descrição',
    'Description' => 'Descrição',
	
    //added for related lists 
    'Project Milestone Name' => 'Nome Marco Projeto',
    'Project Milestone No' => 'Número Marco Projeto',
    'LBL_DEADLINES'=>'Marco Projeto', //CAMPO NON PRESENTE NELLA EN
    'LBL_DEADLINE'=>'Marco Projeto', //CAMPO NON PRESENTE NELLA EN
    'Deadline ID'=>'ID Marco Projeto', //CAMPO NON PRESENTE NELLA EN
	'deadlinename' => 'Nome Marco Projeto', //CAMPO NON PRESENTE NELLA EN
    'deadlines' => 'Marco Projeto', //CAMPO NON PRESENTE NELLA EN
    'Deadline'=>'Marco Projeto', //CAMPO NON PRESENTE NELLA EN
	'ProjectMilestone Name' => 'Nome Marco Projeto',  //CAMPO NON PRESENTE NELLA EN
	

	
    //
    'SINGLE_Deadline' => 'Marco Projeto',     //CAMPO NON PRESENTE NELLA EN
    'LBL_DEADLINE_INFORMATION' => 'Informação Marco Projeto',  //CAMPO NON PRESENTE NELLA EN
    
    'deadlinedate' => 'Data Marco Projeto',  //CAMPO NON PRESENTE NELLA EN
    
    'deadlinetype'=>'Tipologia Marco Projeto',  //CAMPO NON PRESENTE NELLA EN
    //'linktoproject'=>'Relazionata a',
   
   
    
   
    '--none--' => 'nenhum',  //CAMPO NON PRESENTE NELLA EN
    //added for related lists 
    'DeadlineName' => 'Nome Marco Projeto',  //CAMPO NON PRESENTE NELLA EN
    'LBL_SELECT_DEADLINE_BUTTON_TITLE' => 'Selecionar Marco Projeto [Alt+T]',  //CAMPO NON PRESENTE NELLA EN
    'LBL_CREATE_DEADLINE_BUTTON_TITLE' => 'Criar Marco Projeto [Alt+T]',  //CAMPO NON PRESENTE NELLA EN

	'Project Milestones' => 'Marco Projeto',	//crmv@16858
);

?>
