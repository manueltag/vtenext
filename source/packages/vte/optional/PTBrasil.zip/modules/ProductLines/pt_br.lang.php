<?php
$mod_strings = array(
	'LBL_NEW_PRODUCTLINES' => 'Criar Linha de Produtos',
	'ProductLines'=>'Linhas de Produtos',
	'SINGLE_ProductLines'=>'Linha de Produtos',
	'LBL_PRODUCTLINES_INFORMATION'=>'Informações da linha de produtos',
	'LBL_CUSTOM_INFORMATION'=>'Informações personalizadas',
	'LBL_DESCRIPTION_INFORMATION'=>'Descrição Informação',
	'ProductLineName'=>'Nome da linha de produtos',
);
?>