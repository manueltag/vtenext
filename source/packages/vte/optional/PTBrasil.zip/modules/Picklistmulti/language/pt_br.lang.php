<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *
 ********************************************************************************/
/**
 * this file can be used to internationalise the strings present in the picklist
 */
$mod_strings = array(
	'LBL_ASSIGN_BUTTON'=>'Atribuir',
	'ADD_PICKLIST_VALUES'=>'Adicionar valores Lista de Op��es',
	'LBL_EXISTING_PICKLIST_VALUES'=>'Valores existentes Lista de Op��es',
	'LBL_PICKLIST_ADDINFO'=>'Adicionar novas entradas aqui',
	'LBL_SELECT_ROLES'=>'Selecionar fun��o',
	'LBL_NON_EDITABLE_PICKLIST_ENTRIES'=>'Valores n�o edit�veis',
	'EDIT_PICKLIST_VALUE'=>'Editar valores Lista de Op��es',
	'LBL_EDIT_HERE'=>'Substituir por: ',
	'LBL_SELECT_TO_EDIT'=>'Selecionar um valor para editar: ',
	'DELETE_PICKLIST_VALUES'=>'Apagar valores Lista de Op��es',
	'LBL_REPLACE_WITH'=>'Substituir por: ',
	'ASSIGN_PICKLIST_VALUES'=>'Atribuir Valores Lista de Op��es',
	'LBL_PICKLIST_VALUES'=>'Valores Lista de Op��es dispon�veis',
	'LBL_PICKLIST_VALUES_ASSIGNED_TO'=>'Valores Lista de Op��es designados para ',
	'LBL_ADD_TO_OTHER_ROLES'=>'Adicionar outra Fun��o',
	'LBL_OK_BUTTON_LABEL'=>'Ok',
	'LBL_SELECT_ROLES'=>'Selecionar Fun��o',
	'LBL_DISPLAYED_VALUES'=>'Todos os valores acess�veis para a fun��o apresentada abaixo',
	'LBL_ADD_VALUE' => 'Adicionar valor',
	'Code'=>'C�digo',
	'LBL_EMPTY'=>'N�o tem valores',
	'LBL_ERROR_GENERIC'=>'Erro na opera��o',
	'LBL_SUCCESS'=>'Opera��o completada com sucesso',
	'LBL_CODE_NOT_UNIQUE'=>' O c�digo n�o � un�voco! inserir um diferente!',
	'LBL_MANDATORY'=>'Os campos marcados com (*) s�o obrigat�rios',
);
?>
