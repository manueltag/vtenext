<?php
$mod_strings = Array(
	'LBL_NEW_VISITREPORT' => 'Criar Relatório Visita',
	'Visitreport' => 'Relatório Visitas',
	'visitreportname' => 'Nome Visita',
	'Visitreport Name' => 'Nome Visita',
	'ModuleFieldLabel' => 'ModuleFieldLabel Text',

	'LBL_CUSTOM_INFORMATION' => 'Informação Personalizada',
	'LBL_VISITREPORT_INFORMATION' => 'Informação Visita',
	'LBL_DESCRIPTION_INFORMATION' => 'Despesas',
	'LBL_SCOPO_INFORMATION' => 'Finalidade da Visita',
	'LBL_RESULT_INFORMATION' => 'Resultado da Visita',

	'Description'=>'Descrição',
	'Created Time' => 'tempo criado',
 	'Modified Time' => 'Data e Hora de Modificação',
	'accountid'=>'Conta',
	'kmpercorsi'=>'Km Percorridos',
	'spautostr'=>'Despesas Pedágio',
	'spvitoall'=>'custos de Alimentação e alojamento',
	'spother'=>'Outras Despesas',
	'scopovisit'=>'Finalidade Visita',
	'visitdate'=>'Data Visita',
	'visitnote'=>'Documento Visita',
	'ourproduct'=>'Interesse pelos nossos Produtos',
	'descspother'=>'Descrição de outras Despesas',
	'Visitreport No'=>'Número Visita',

	'LBL_ADD_EVENT'=>'Adicionar Evento',
	'LBL_ADD_TASK'=>'Adicionar Tarefa',
	
	'Conoscenza'=>'contato',
		'Related To'=>'Relacionado a',
		'Presentazione'=>'apresentação',
		'Prodotti'=>'produtos',
		'Consegna'=>'entrega',
		'Offerta'=>'oferta',
		'Ritiro offerta'=>'Retirada oferta',
		'Consulenza'=>'conselho',
		'Voci di capitolato'=>'Itens de especificações',
		'Analisi scientifiche'=>'A análise científica',
		'Campioni'=>'Amostras',
		'Altro'=>'outro',
		'Consegna Offerta'=>'oferta Entrega',
		'Presentazione Prodotti'=>'Apresentação de produtos',
		'Stesura capitolato'=>'Elaboração de especificações',
		'Controllo avanzamento'=>'controle Progresso',
		
);

?>
