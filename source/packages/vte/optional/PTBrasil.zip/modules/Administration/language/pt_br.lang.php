<?php
$mod_strings = array (
  'LBL_MODULE_NAME' => 'Administração',
  'LBL_MODULE_TITLE' => 'Administracão: Principal',
  'LBL_NEW_FORM_TITLE' => 'Nova Conta',
  'ERR_DELETE_RECORD' => 'Por favor, especifique um número recorde para excluir a conta.',

);
?>