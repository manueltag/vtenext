<?php
$mod_strings = array(
'com_vtiger_workflow'=>'Workflow',
'VTEmailTask' => 'Enviar Email',
'VTEntityMethodTask' => 'Chamar Função Personalizada',
'VTCreateTodoTask' => 'Criar Para fazer',
'VTCreateEventTask' => 'Criar Evento',
'LBL_EDIT_TASK'=>'Editar Tarefa;',
'LBL_EDIT_TASK_TITLE'=>'Editar uma tarefa existente ou criar uma nova tarefa',
'LBL_EDIT_WORKFLOW'=>'Editar Workflow',
'LBL_EDIT_WORKFLOW_TITLE'=>'Editar um fluxo de trabalho existente ou criar um novo fluxo de trabalho',
//'LBL_FROM_TEMPLATE'=>'Dal Template', //duplicato anche sul file en_us
'LBL_NEW_WORKFLOW'=>'Novo Workflow',
'LBL_NEW_TEMPLATE'=>'Salvar como Modelo',
'LBL_CREATE_WORKFLOW_FOR'=>'Criar um Workflow para',
'LBL_FOR_MODULE'=>'Para Módulo',
'LBL_FROM_TEMPLATE'=>'Do Modelo',
'LBL_CHOOSE_A_TEMPLATE'=>'Escolher um Modelo',
'LBL_VALIDATION_MISSING_MANDATORY_FIELDS'=>'Por favor, preencha os campos obrigatórios.',
'LBL_VALIDATION_INVALID_DATE_RANGE'=>'Data / hora de início é posterior à data / hora final',
'LBL_ERROR_NO_WORKFLOW'=>'Esse fluxo de trabalho não existe',
'LBL_ERROR_NO_TASK'=>'Esta tarefa não existe',
'LBL_ERROR_NOT_ADMIN'=>'Você não está autorizado a acessar este módulo.',
'LBL_CREATE_WORKFLOW'=>'Criar Workflow',
'LBL_WORKFLOW_LIST'=>'Lista Workflow',
'LBL_AVAILABLE_WORKLIST_LIST'=>'Workflow Disponíveis',
'LBL_LOADING'=>'Carregando...',
'LBL_VALIDATION_ERROR'=>'Erro Validação',
'LBL_SELECT_OPTION_DOTDOTDOT'=>'Selecionar Opção...',
'LBL_WORKFLOW_NOTE_CRON_CONFIG'=>'NOTA: Por favor, configurar o script cron Fluxo de Trabalho',
'LBL_NO_TEMPLATES'=>'Nenhum Modelo',
'LBL_SELECT'=>'Selecionar',
'LBL_MESSAGE'=>'Mensagem',
//crmv@18199
'VTUpdateFieldTask' => 'Modificar um Campo',
'LBL_FIELD_VALUE'=>'Valor',
//crmv@18199e
);
?>