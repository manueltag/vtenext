<?php
$mod_strings = Array(
	'LBL_NEW_DDT' => 'Criar Documento de Frete',
	'Ddt' => 'Doc. Frete',
	'LBL_CUSTOM_INFORMATION' => 'Informa��es Personalizadas',
	'LBL_DDT_INFORMATION' => 'Informa��es Documento de Frete',
	'LBL_DESCRIPTION_INFORMATION'=>'Informa��o Descri��o',
	'LBL_TERMS_INFORMATION' => 'Prazos e Condi��es',
	'SINGLE_Ddt' => 'Documento de Frete',
	'Add Invoice' => 'Criar Fatura',
	'Customer No' => 'N�mero Cliente',
	'--None--' => '--Nenhum--',
	'Ddt No'=>'N�mero Documento de Frete',	//crmv@18564
	'Condizione di Consegna'=>'Condi��o de Entrega',	//VTE br
	'Product Name'=>'Nome Produto',
	'Service Name'=>'Nome Servi�o',
	'Quantity'=>'Quantidade',
	'Sub Total'=>'Total',
);
?>