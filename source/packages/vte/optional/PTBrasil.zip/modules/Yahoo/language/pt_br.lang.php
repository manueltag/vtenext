<?php
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Contas',
'LBL_MODULE_TITLE'=>'Contas: Principal',
'LBL_SEARCH_FORM_TITLE'=>'Pesquisa Conta',
'LBL_LIST_FORM_TITLE'=>'Lista Conta',
'LBL_NEW_FORM_TITLE'=>'Nova Conta',
'ERR_DELETE_RECORD'=>'Por favor, selecione um número de registro para excluir a conta.',
);

?>
