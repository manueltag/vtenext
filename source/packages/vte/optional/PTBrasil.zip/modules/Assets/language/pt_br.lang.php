<?php
$mod_strings = Array(
/*some general information*/
'LBL_NEW_ASSETS' => 'Criar Instala��o',
'LBL_MODULE_NAME'=>'Instala��es',
'SINGLE_Assets'=>'Instala��o',

/*blocks for the module*/
'LBL_ASSET_INFORMATION'=>'Informa��o Instala��o',
'LBL_CUSTOM_INFORMATION'=>'Informa��o Personalizada',
'LBL_DESCRIPTION_INFORMATION'=>'Informa��o Descri��o',

/*fields for the module*/
'Assets'=>'Instala��es',
'Asset Name' => 'Nome Instala��o',
'Customer Name'=>'Conta',
'Product Name'=>'Produto',
'Serial Number'=>'N�mero de S�rie',
'Asset No'=>' N�mero Instala��o',
'Date Sold'=>'Data de Venda',
'Date in Service'=>'Data em Servi�o',//asas
'Status'=>'Status',
'Shipping Method'=>'M�todo Entrega',
'Shipping Tracking Number'=>'N�mero Rastreamento Entrega',
'Tag Number'=>' N�mero Tag',
'Notes'=>'Notas',
'Invoice Name'=>'Nome Fatura',

/*picklist values*/
'In Service'=>'Em Servi�o',
'Out-of-service'=>'Fora Servi�o',


);
?>
