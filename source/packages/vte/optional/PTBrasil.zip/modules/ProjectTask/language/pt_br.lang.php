<?php
$mod_strings = Array(
	'LBL_NEW_PROJECTTASK' => 'Criar Tarefa Projeto',
    'LBL_MODULE_NAME'=>'Tarefas Projeto',
    'LBL_MODULE_TITLE'=>'Tarefas Projeto',
	//crmv@521translation start
	'LBL_NEW_PROJECTTASK'=>'Novas Tarefas Projeto',
	'LBL_PROJECTTASKS'=>'Tarefas Projeto',
    'LBL_PROJECTTASK'=>'Tarefa Projeto',
	'Project Task ID'=>'ID Tarefa Projeto',
    'projecttasks' => 'Tarefas Projeto',
    'LBL_NEW_OPERATION'=>'Nova Tarefa Projeto', //CAMPO NON PRESENTE NELLA EN
    'LBL_OPERATIONS'=>'Tarefas Projeto', //CAMPO NON PRESENTE NELLA EN
    'LBL_OPERATION'=>'Tarefas Projeto', //CAMPO NON PRESENTE NELLA EN
    'Operation ID'=>'ID Tarefa Projeto', //CAMPO NON PRESENTE NELLA EN
    'operationname' => 'Nome Tarefa Projeto', //CAMPO NON PRESENTE NELLA EN
    'operations' => 'Tarefas Projeto', //CAMPO NON PRESENTE NELLA EN
    //added this to translate the module name in the main app menu
    'Operation'=>'Tarefas Projeto', //CAMPO NON PRESENTE NELLA EN
	'ProjectTask' => 'Tarefas Projeto',
	'SINGLE_ProjectTask' => 'Tarefa Projeto',
    'Related Project' => 'Projeto Relacionado',
	'Start Date' => 'Data Início',
	'End Date' => 'Data Final',
	'Project Task Number' => 'Código Tarefa Projeto',
	//crmv@521translation end
	'LBL_CUSTOM_INFORMATION' => 'Informação Personalizada',
    'LBL_PROJECT_TASK_INFORMATION' => 'Informação Tarefa Projeto',
    'LBL_DESCRIPTION_INFORMATION' => 'Informação Descrição',
    'Assigned To' => 'Atribuída a',
	'Priority' => 'Prioridade',
	'ProjectTask Name' => 'Nome Tarefa Projeto',  //CAMPO NON PRESENTE NELLA EN
	'Progress' => 'Progresso',
	'Type' => 'Tipo',
	'Worked Hours' => 'Horas Trabalhadas',
	'Project Task Name' => 'Nome Tarefa Projeto',
	'Project Task No' => 'Número Tarefa Projeto',
    'SINGLE_Operation' => 'Tarefa Projeto', //CAMPO NON PRESENTE NELLA EN
	'Related To' => 'Relacionado a',
    'projectid' => 'Relacionado a',
    
    //'linktoproject' => 'Relazionata a',
    'operationpriority' => 'Prioridade;', //CAMPO NON PRESENTE NELLA EN
    'operationprogress' => 'Progresso', //CAMPO NON PRESENTE NELLA EN
    'operationtype'=>'Tipo', //CAMPO NON PRESENTE NELLA EN
    'operationhours'=>'Horas Trabalhadas', //CAMPO NON PRESENTE NELLA EN
    'startdate'=>'Data Início', //CAMPO NON PRESENTE NELLA EN
    'enddate'=>'Data  Final', //CAMPO NON PRESENTE NELLA EN
    'administrative' => 'administrativo',
    'operative' => 'operacional',
    'other' => 'outro',
    'low' => 'baixo',
    'normal' => 'normal',
    'high' => 'alto',
    'Created Time' => 'tempo criado',
    'Modified Time' => 'Data e Hora de Modificação',
    'Description' => 'Descrição',
    'description' => 'Descrição',
    '--none--' => '-- nenhum --', //CAMPO NON PRESENTE NELLA EN
    //added for related lists 
    'OperationName' => 'Nome Tarefa Projeto', //CAMPO NON PRESENTE NELLA EN
    'projectname' => 'Nome Projeto', //CAMPO NON PRESENTE NELLA EN
    'operationnumber' => 'Código Tarefa Projeto', //CAMPO NON PRESENTE NELLA EN
    
	'Project Tasks' => 'Tarefas Projeto',	//crmv@16858
	'Add Note'=>'Criar Documento',		//crmv@18828
	'SalesOrder'=>'Pedido de Vendas',
);
?>