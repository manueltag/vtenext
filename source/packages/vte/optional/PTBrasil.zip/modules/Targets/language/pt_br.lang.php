<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

$mod_strings = Array(
	'LBL_NEW_TARGETS' => 'Criar Alvo',
	'Targets' => 'Alvo',
	'SINGLE_Targets' => 'Alvo',
	'LBL_TARGETS_INFORMATION' => 'Informações Alvo',
	'LBL_CUSTOM_INFORMATION' => 'Informações personalizadas',
	'LBL_DESCRIPTION_INFORMATION' => 'Descrição Informação',
	'Target Name' => 'Nome Alvo',
	'Target No' => 'Número Alvo',
	'Target Type' => 'Tipo Alvo',
	'Target State' => 'Status Alvo',
	'End Time' => 'Fechamento Alvo',
	'Assigned To' => 'Atribuído a',
	'Description' => 'Descrição',
	'Created Time' => 'tempo criado',
  	'Modified Time' => 'Data e Hora de Modificação',
	'LBL_LOAD_LIST' => 'Carregar Lista',
	'Select One' => 'Selecionar Um',
	'LBL_LOAD_REPORT'=>'relat�rio de carga',
);
?>
